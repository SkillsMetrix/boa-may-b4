
from fastapi import FastAPI

app= FastAPI()

users=[{'id':101,'name':'admin','city':'delhi'}]
@app.get("/")
def loadData():
    return{"message":"welcome to fastAPI APP"}

@app.get("/loadusers")
def loadData():
    return{"message":users}
