
a=10
b=50

if a>b:
    print('statement is true')
else:
    print('statement is false')