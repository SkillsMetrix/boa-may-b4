
a= int(input('Enter First Number '))
b= int(input('Enter Second Number '))
c=a+b
print(f"The calculation is : {c}")