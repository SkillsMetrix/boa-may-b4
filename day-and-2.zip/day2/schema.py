
from pydantic import BaseModel

# schema created
class User(BaseModel):
    uname:str
    email:str
    city:str