# import module
from fastapi import FastAPI,status,HTTPException,APIRouter,Depends
from . import schema,models
from sqlalchemy.orm import Session
from .database import engine,get_connection

router= APIRouter(tags=["User Loading App"])


@router.get('/loadusers')
def loadUsers(db:Session=Depends(get_connection)):
    data= db.query(models.UserApp).all()
    return {'data':data}



@router.get('/loaduser/{name}')
def loadUser(name,db:Session=Depends(get_connection)):
    post=db.query(models.UserApp).filter(models.UserApp.uname == name).first()
    if post == None:
        raise HTTPException(status_code=status.HTTP_404_NOT_FOUND,detail="User With Given Name ,Not Found")
    return {'userdata': post}









    





