# print the statement
print('welcome to python')

# declare var

myName='amarjeet'

pincode=1212
city='pune'

print(myName,pincode,city)

print(f"My Name is {myName} ,my pincode is {pincode} and my city is {city}")