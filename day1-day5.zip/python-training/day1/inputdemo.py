
data= input('Enter UserName: ')

print(f"Welcome: {data}")