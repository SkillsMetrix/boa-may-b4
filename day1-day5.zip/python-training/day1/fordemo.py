# declare array
userNames=['rohit','Aman','parul']

for uname in userNames:
    print(f" userdetails: {uname}")

