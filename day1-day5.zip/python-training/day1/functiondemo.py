
data1= int(input('Enter Value1 '))
data2= int(input('Enter Value2 '))

def addApp(a,b):
    c=a+b
    print(f" sum is {c} ")


addApp(data1,data2)