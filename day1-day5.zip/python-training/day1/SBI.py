from RBIApp import RBI

class SBI(RBI):
    initialBalance=100
    def giveLoans(self):
        return('SBI Provides Loan')
    def withdrawAmount(self):
        amount=int(input('Enter Amount to withdraw'))
        self.initialBalance -=amount
        print('sbi withdraw')
    def depositAmount(self):
        print('in sbi amount deposited')
    def checkBalance(self):
        return ('sbi check balance' ,self.initialBalance)


sbi= SBI()
sbi.giveLoans()
sbi.withdrawAmount()
print(sbi.checkBalance())